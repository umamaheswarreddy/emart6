export class Product {

    id: string;
    name: string;
    price: number;
    photo: string;

}