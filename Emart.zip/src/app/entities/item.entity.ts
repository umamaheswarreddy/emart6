import { Product } from './product.entity';

export class Item {

    product: Product;
    quantity: number;

}